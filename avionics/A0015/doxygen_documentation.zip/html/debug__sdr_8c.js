var debug__sdr_8c =
[
    [ "debug_callback_handler", "debug__sdr_8c.html#a2059f266410d94cc7af30ef3c3dee1f1", null ],
    [ "debug_clear", "debug__sdr_8c.html#a6767eb4539631e752226706452fdd633", null ],
    [ "debug_init", "debug__sdr_8c.html#aad252f26e482124f6d942f675fbc6c95", null ],
    [ "debug_log", "debug__sdr_8c.html#a4860b75cd8b4184abcc783212e2fc796", null ]
];