var annotated_dup =
[
    [ "_BARO_PRESET", "struct___b_a_r_o___p_r_e_s_e_t.html", null ],
    [ "_DEBUG_HANDLE", "struct___d_e_b_u_g___h_a_n_d_l_e.html", null ],
    [ "_ERROR_CALLBACK", "struct___e_r_r_o_r___c_a_l_l_b_a_c_k.html", null ],
    [ "_IMU_CONVERTED", "struct___i_m_u___c_o_n_v_e_r_t_e_d.html", null ],
    [ "_IMU_DATA", "struct___i_m_u___d_a_t_a.html", null ],
    [ "_MAHONY_FILTER", "struct___m_a_h_o_n_y___f_i_l_t_e_r.html", "struct___m_a_h_o_n_y___f_i_l_t_e_r" ],
    [ "_QUAT", "struct___q_u_a_t.html", null ],
    [ "_STATE_ESTIMATION", "struct___s_t_a_t_e___e_s_t_i_m_a_t_i_o_n.html", null ],
    [ "_VECTOR_3F", "struct___v_e_c_t_o_r__3_f.html", null ],
    [ "SENSOR_DATA", "struct_s_e_n_s_o_r___d_a_t_a.html", null ],
    [ "TEXT_MESSAGE", "struct_t_e_x_t___m_e_s_s_a_g_e.html", null ]
];