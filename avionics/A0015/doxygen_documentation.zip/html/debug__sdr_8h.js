var debug__sdr_8h =
[
    [ "_DEBUG_HANDLE", "struct___d_e_b_u_g___h_a_n_d_l_e.html", null ],
    [ "debug_assert", "debug__sdr_8h.html#a9994f51a081c551d09c5048da515d9ce", null ],
    [ "debug_ignore_emulator_warnings_start", "debug__sdr_8h.html#a212425c5fb8217cc5d5c79e9075de5db", null ],
    [ "debug_ignore_emulator_warnings_stop", "debug__sdr_8h.html#a765f2b931ae6e333815002af5aa39ecd", null ],
    [ "debug_log_assert", "debug__sdr_8h.html#a0407adc20759d631d18faec5a046303c", null ],
    [ "debug_log_msg", "debug__sdr_8h.html#aa58696bab73368b16cd3dd7aaf4bd1ae", null ],
    [ "debug_callback_handler", "debug__sdr_8h.html#a2059f266410d94cc7af30ef3c3dee1f1", null ],
    [ "debug_clear", "debug__sdr_8h.html#a6767eb4539631e752226706452fdd633", null ],
    [ "debug_init", "debug__sdr_8h.html#aad252f26e482124f6d942f675fbc6c95", null ],
    [ "debug_log", "debug__sdr_8h.html#a4860b75cd8b4184abcc783212e2fc796", null ]
];