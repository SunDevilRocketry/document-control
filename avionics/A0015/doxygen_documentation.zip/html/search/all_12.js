var searchData=
[
  ['qa_20level_3a_20safety_20critical_0',['QA level: Safety Critical',['../md___reqs_2srd.html#autotoc_md1',1,'']]],
  ['quat_5fadd_1',['quat_add',['../math__sdr_8c.html#a39a2b8372792545fd56fb2cf10cc2121',1,'quat_add(QUAT a, QUAT b):&#160;math_sdr.c'],['../math__sdr_8h.html#a39a2b8372792545fd56fb2cf10cc2121',1,'quat_add(QUAT a, QUAT b):&#160;math_sdr.c']]],
  ['quat_5fconj_2',['quat_conj',['../math__sdr_8c.html#a15e249ec2c19e7fbc9876bc4d6b020d1',1,'quat_conj(QUAT q):&#160;math_sdr.c'],['../math__sdr_8h.html#a15e249ec2c19e7fbc9876bc4d6b020d1',1,'quat_conj(QUAT q):&#160;math_sdr.c']]],
  ['quat_5fdot_3',['quat_dot',['../math__sdr_8c.html#af792299517d0078c72d5c78a43962fcc',1,'quat_dot(QUAT a, QUAT b):&#160;math_sdr.c'],['../math__sdr_8h.html#af792299517d0078c72d5c78a43962fcc',1,'quat_dot(QUAT a, QUAT b):&#160;math_sdr.c']]],
  ['quat_5fis_5ffinite_4',['quat_is_finite',['../math__sdr_8c.html#a25d50dbc32b2651995490e4dcf528051',1,'quat_is_finite(QUAT quaternion):&#160;math_sdr.c'],['../math__sdr_8h.html#a25d50dbc32b2651995490e4dcf528051',1,'quat_is_finite(QUAT quaternion):&#160;math_sdr.c']]],
  ['quat_5fmult_5',['quat_mult',['../math__sdr_8c.html#a51b59e9037341c381f52ad36facc3910',1,'quat_mult(QUAT a, QUAT b):&#160;math_sdr.c'],['../math__sdr_8h.html#a51b59e9037341c381f52ad36facc3910',1,'quat_mult(QUAT a, QUAT b):&#160;math_sdr.c']]],
  ['quat_5fnormalize_6',['quat_normalize',['../math__sdr_8c.html#a80082b9422cfa13942abea603d04ede6',1,'quat_normalize(QUAT q):&#160;math_sdr.c'],['../math__sdr_8h.html#a80082b9422cfa13942abea603d04ede6',1,'quat_normalize(QUAT q):&#160;math_sdr.c']]],
  ['quat_5frotate_5fbody_5fto_5fworld_7',['quat_rotate_body_to_world',['../math__sdr_8c.html#a287b99ef5b06b0554e984beb65032d88',1,'quat_rotate_body_to_world(QUAT attitude, QUAT vector_body):&#160;math_sdr.c'],['../math__sdr_8h.html#a287b99ef5b06b0554e984beb65032d88',1,'quat_rotate_body_to_world(QUAT attitude, QUAT vector_body):&#160;math_sdr.c']]],
  ['quat_5frotate_5fworld_5fto_5fbody_8',['quat_rotate_world_to_body',['../math__sdr_8c.html#aa0dfee83c10a6c8abc915d45b85e7839',1,'quat_rotate_world_to_body(QUAT attitude, QUAT vector_world):&#160;math_sdr.c'],['../math__sdr_8h.html#aa0dfee83c10a6c8abc915d45b85e7839',1,'quat_rotate_world_to_body(QUAT attitude, QUAT vector_world):&#160;math_sdr.c']]],
  ['quat_5fscale_9',['quat_scale',['../math__sdr_8c.html#abc7bc159e7cbeb471b99b92dec60e2db',1,'quat_scale(QUAT q, float s):&#160;math_sdr.c'],['../math__sdr_8h.html#abc7bc159e7cbeb471b99b92dec60e2db',1,'quat_scale(QUAT q, float s):&#160;math_sdr.c']]]
];
