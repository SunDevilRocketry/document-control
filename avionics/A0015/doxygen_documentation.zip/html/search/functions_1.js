var searchData=
[
  ['debug_5fcallback_5fhandler_0',['debug_callback_handler',['../debug__sdr_8c.html#a2059f266410d94cc7af30ef3c3dee1f1',1,'debug_callback_handler(void):&#160;debug_sdr.c'],['../debug__sdr_8h.html#a2059f266410d94cc7af30ef3c3dee1f1',1,'debug_callback_handler(void):&#160;debug_sdr.c']]],
  ['debug_5fclear_1',['debug_clear',['../debug__sdr_8c.html#a6767eb4539631e752226706452fdd633',1,'debug_clear(void):&#160;debug_sdr.c'],['../debug__sdr_8h.html#a6767eb4539631e752226706452fdd633',1,'debug_clear(void):&#160;debug_sdr.c']]],
  ['debug_5finit_2',['debug_init',['../debug__sdr_8c.html#aad252f26e482124f6d942f675fbc6c95',1,'debug_init(debug_write_callback write_function, overflow_callback overflow_function):&#160;debug_sdr.c'],['../debug__sdr_8h.html#aad252f26e482124f6d942f675fbc6c95',1,'debug_init(debug_write_callback write_function, overflow_callback overflow_function):&#160;debug_sdr.c']]],
  ['debug_5flog_3',['debug_log',['../debug__sdr_8c.html#a4860b75cd8b4184abcc783212e2fc796',1,'debug_log(const char *message, size_t len, DEBUG_LEVEL log_level):&#160;debug_sdr.c'],['../debug__sdr_8h.html#a4860b75cd8b4184abcc783212e2fc796',1,'debug_log(const char *message, size_t len, DEBUG_LEVEL log_level):&#160;debug_sdr.c']]]
];
