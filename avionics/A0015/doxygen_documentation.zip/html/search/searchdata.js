var indexSectionsWithContent =
{
  0: "1234567_acdefilmnpqrstuvx",
  1: "_st",
  2: "cdemst",
  3: "cdempqstv",
  4: "ai",
  5: "imv",
  6: "m",
  7: "adru",
  8: "1234567acdeflmnpqrstx"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "defines",
  8: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Macros",
  8: "Pages"
};

