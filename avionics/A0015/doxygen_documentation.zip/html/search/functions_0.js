var searchData=
[
  ['clamp_5ffloat_0',['clamp_float',['../math__sdr_8c.html#a46feb9c0a2d90f0546b60b7f5ecf2579',1,'clamp_float(float value, float minimum, float maximum):&#160;math_sdr.c'],['../math__sdr_8h.html#a46feb9c0a2d90f0546b60b7f5ecf2579',1,'clamp_float(float value, float minimum, float maximum):&#160;math_sdr.c']]],
  ['crc32_1',['crc32',['../math__sdr_8c.html#a352fcee608de97a332174266e00f8d40',1,'crc32(const uint8_t *data, size_t len):&#160;math_sdr.c'],['../math__sdr_8h.html#a352fcee608de97a332174266e00f8d40',1,'crc32(const uint8_t *data, size_t len):&#160;math_sdr.c']]]
];
