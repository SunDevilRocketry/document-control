var searchData=
[
  ['rad_5fto_5fdeg_0',['rad_to_deg',['../math__sdr_8h.html#a59508287675f00596dafd0cb869294b3',1,'math_sdr.h']]],
  ['requirements_20document_1',['SDR &quot;mod&quot; Library Software Requirements Document',['../md___reqs_2srd.html#autotoc_md0',1,'']]]
];
