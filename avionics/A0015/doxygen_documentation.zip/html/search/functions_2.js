var searchData=
[
  ['error_5ffail_5ffast_0',['error_fail_fast',['../error__sdr_8c.html#ad8a2c0b32e5bfb8386c2a98a7456cad7',1,'error_fail_fast(volatile ERROR_CODE error_code):&#160;error_sdr.c'],['../error__sdr_8h.html#ad8a2c0b32e5bfb8386c2a98a7456cad7',1,'error_fail_fast(volatile ERROR_CODE error_code):&#160;error_sdr.c']]],
  ['eul_5fto_5fquat_1',['eul_to_quat',['../math__sdr_8c.html#a1b5b367b89029ee9dfcf5ec799d0be45',1,'eul_to_quat(float yaw, float pitch, float roll):&#160;math_sdr.c'],['../math__sdr_8h.html#a1b5b367b89029ee9dfcf5ec799d0be45',1,'eul_to_quat(float yaw, float pitch, float roll):&#160;math_sdr.c']]]
];
