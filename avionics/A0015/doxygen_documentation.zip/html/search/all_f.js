var searchData=
[
  ['mahony_0',['2.7. Mahony',['../md___reqs_2srd.html#autotoc_md11',1,'']]],
  ['mahony_2ec_1',['mahony.c',['../mahony_8c.html',1,'']]],
  ['mahony_2eh_2',['mahony.h',['../mahony_8h.html',1,'']]],
  ['mahony_5ffilter_3',['MAHONY_FILTER',['../mahony_8h.html#a6a9127794b2f26ad091bd3cb698a5c73',1,'mahony.h']]],
  ['mahony_5finit_4',['mahony_init',['../mahony_8c.html#aac72c4223c091dacee40f9948a191e11',1,'mahony_init(MAHONY_FILTER *filter, QUAT initial_attitude, float proportional_gain, float integral_gain):&#160;mahony.c'],['../mahony_8h.html#aac72c4223c091dacee40f9948a191e11',1,'mahony_init(MAHONY_FILTER *filter, QUAT initial_attitude, float proportional_gain, float integral_gain):&#160;mahony.c']]],
  ['mahony_5fstatus_5',['MAHONY_STATUS',['../mahony_8h.html#a5720f4880af1f92b35122f19ae6fccd8',1,'mahony.h']]],
  ['mahony_5fupdate_5fgyro_6',['mahony_update_gyro',['../mahony_8c.html#a17003a0a97386796157d53983a13234c',1,'mahony_update_gyro(MAHONY_FILTER *filter, VECTOR_3F gyro_body_rad_s, float delta_time_s):&#160;mahony.c'],['../mahony_8h.html#a17003a0a97386796157d53983a13234c',1,'mahony_update_gyro(MAHONY_FILTER *filter, VECTOR_3F gyro_body_rad_s, float delta_time_s):&#160;mahony.c']]],
  ['mahony_5fupdate_5fimu_7',['mahony_update_imu',['../mahony_8c.html#a805c7d773efcbd98634b4e71122919ea',1,'mahony_update_imu(MAHONY_FILTER *filter, VECTOR_3F gyro_body_rad_s, VECTOR_3F accel_body, float delta_time_s, bool use_accel):&#160;mahony.c'],['../mahony_8h.html#a805c7d773efcbd98634b4e71122919ea',1,'mahony_update_imu(MAHONY_FILTER *filter, VECTOR_3F gyro_body_rad_s, VECTOR_3F accel_body, float delta_time_s, bool use_accel):&#160;mahony.c']]],
  ['math_8',['2.4. Math',['../md___reqs_2srd.html#autotoc_md8',1,'']]],
  ['math_5fsdr_2ec_9',['math_sdr.c',['../math__sdr_8c.html',1,'']]],
  ['math_5fsdr_2eh_10',['math_sdr.h',['../math__sdr_8h.html',1,'']]],
  ['mod_11',['mod',['../md__r_e_a_d_m_e.html',1,'']]],
  ['mod_20library_20software_20requirements_20document_12',['SDR &quot;mod&quot; Library Software Requirements Document',['../md___reqs_2srd.html#autotoc_md0',1,'']]]
];
