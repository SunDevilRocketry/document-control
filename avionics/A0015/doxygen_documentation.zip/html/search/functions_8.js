var searchData=
[
  ['vector_5fadd_0',['vector_add',['../math__sdr_8c.html#a939e403ddc460d7756bdf6f70cbf40e0',1,'vector_add(VECTOR_3F a, VECTOR_3F b):&#160;math_sdr.c'],['../math__sdr_8h.html#a939e403ddc460d7756bdf6f70cbf40e0',1,'vector_add(VECTOR_3F a, VECTOR_3F b):&#160;math_sdr.c']]],
  ['vector_5fcross_1',['vector_cross',['../math__sdr_8c.html#a6bfbb9fa2b823caf03d83a81869a3124',1,'vector_cross(VECTOR_3F a, VECTOR_3F b):&#160;math_sdr.c'],['../math__sdr_8h.html#a6bfbb9fa2b823caf03d83a81869a3124',1,'vector_cross(VECTOR_3F a, VECTOR_3F b):&#160;math_sdr.c']]],
  ['vector_5fis_5ffinite_2',['vector_is_finite',['../math__sdr_8c.html#a8fc83ab0b8cbbb3dd504a47a47026a2d',1,'vector_is_finite(VECTOR_3F vector):&#160;math_sdr.c'],['../math__sdr_8h.html#a8fc83ab0b8cbbb3dd504a47a47026a2d',1,'vector_is_finite(VECTOR_3F vector):&#160;math_sdr.c']]],
  ['vector_5fmagnitude_3',['vector_magnitude',['../math__sdr_8c.html#a5147d048e03fff66033b1f6fc4f24a7f',1,'vector_magnitude(VECTOR_3F vector):&#160;math_sdr.c'],['../math__sdr_8h.html#a5147d048e03fff66033b1f6fc4f24a7f',1,'vector_magnitude(VECTOR_3F vector):&#160;math_sdr.c']]],
  ['vector_5fnormalize_4',['vector_normalize',['../math__sdr_8c.html#a0b439d054d3c0bd2e9f54b6927383bce',1,'vector_normalize(VECTOR_3F *vector):&#160;math_sdr.c'],['../math__sdr_8h.html#a0b439d054d3c0bd2e9f54b6927383bce',1,'vector_normalize(VECTOR_3F *vector):&#160;math_sdr.c']]],
  ['vector_5fscale_5',['vector_scale',['../math__sdr_8c.html#a37e8e1bdb9dcaabd6589803901366af3',1,'vector_scale(VECTOR_3F vector, float scalar):&#160;math_sdr.c'],['../math__sdr_8h.html#a37e8e1bdb9dcaabd6589803901366af3',1,'vector_scale(VECTOR_3F vector, float scalar):&#160;math_sdr.c']]]
];
