var searchData=
[
  ['text_5fmessage_0',['TEXT_MESSAGE',['../struct_t_e_x_t___m_e_s_s_a_g_e.html',1,'']]]
];
