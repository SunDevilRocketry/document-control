var math__sdr_8c =
[
    [ "clamp_float", "math__sdr_8c.html#a46feb9c0a2d90f0546b60b7f5ecf2579", null ],
    [ "crc32", "math__sdr_8c.html#a352fcee608de97a332174266e00f8d40", null ],
    [ "eul_to_quat", "math__sdr_8c.html#a1b5b367b89029ee9dfcf5ec799d0be45", null ],
    [ "quat_add", "math__sdr_8c.html#a39a2b8372792545fd56fb2cf10cc2121", null ],
    [ "quat_conj", "math__sdr_8c.html#a15e249ec2c19e7fbc9876bc4d6b020d1", null ],
    [ "quat_dot", "math__sdr_8c.html#af792299517d0078c72d5c78a43962fcc", null ],
    [ "quat_is_finite", "math__sdr_8c.html#a25d50dbc32b2651995490e4dcf528051", null ],
    [ "quat_mult", "math__sdr_8c.html#a51b59e9037341c381f52ad36facc3910", null ],
    [ "quat_normalize", "math__sdr_8c.html#a80082b9422cfa13942abea603d04ede6", null ],
    [ "quat_rotate_body_to_world", "math__sdr_8c.html#a287b99ef5b06b0554e984beb65032d88", null ],
    [ "quat_rotate_world_to_body", "math__sdr_8c.html#aa0dfee83c10a6c8abc915d45b85e7839", null ],
    [ "quat_scale", "math__sdr_8c.html#abc7bc159e7cbeb471b99b92dec60e2db", null ],
    [ "vector_add", "math__sdr_8c.html#a939e403ddc460d7756bdf6f70cbf40e0", null ],
    [ "vector_cross", "math__sdr_8c.html#a6bfbb9fa2b823caf03d83a81869a3124", null ],
    [ "vector_is_finite", "math__sdr_8c.html#a8fc83ab0b8cbbb3dd504a47a47026a2d", null ],
    [ "vector_magnitude", "math__sdr_8c.html#a5147d048e03fff66033b1f6fc4f24a7f", null ],
    [ "vector_normalize", "math__sdr_8c.html#a0b439d054d3c0bd2e9f54b6927383bce", null ],
    [ "vector_scale", "math__sdr_8c.html#a37e8e1bdb9dcaabd6589803901366af3", null ]
];