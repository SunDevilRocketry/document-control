var mahony_8c =
[
    [ "mahony_init", "mahony_8c.html#aac72c4223c091dacee40f9948a191e11", null ],
    [ "mahony_update_gyro", "mahony_8c.html#a17003a0a97386796157d53983a13234c", null ],
    [ "mahony_update_imu", "mahony_8c.html#a805c7d773efcbd98634b4e71122919ea", null ]
];