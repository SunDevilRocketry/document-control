var error__sdr_8h =
[
    [ "_ERROR_CALLBACK", "struct___e_r_r_o_r___c_a_l_l_b_a_c_k.html", null ],
    [ "TEXT_MESSAGE", "struct_t_e_x_t___m_e_s_s_a_g_e.html", null ],
    [ "assert_fail_fast", "error__sdr_8h.html#ae0abf71631c31f0658d861a02a93ccb9", null ],
    [ "assert_return", "error__sdr_8h.html#a9594678750668d570b3e6cca6f398812", null ],
    [ "error_fail_fast", "error__sdr_8h.html#ad8a2c0b32e5bfb8386c2a98a7456cad7", null ]
];