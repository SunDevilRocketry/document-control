var dir_7cbd3f66d3914c13e7c0206e22e05e5e =
[
    [ "debug_sdr.c", "debug__sdr_8c.html", "debug__sdr_8c" ],
    [ "debug_sdr.h", "debug__sdr_8h.html", "debug__sdr_8h" ]
];