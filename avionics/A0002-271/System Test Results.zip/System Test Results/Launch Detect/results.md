Results:

Case 1: PASS
[extracted_data.csv](https://github.com/user-attachments/files/33293254/extracted_data.csv)
[extracted_preset.json](https://github.com/user-attachments/files/33293253/extracted_preset.json)

Remarks: Launch detect is triggered with 5 samples along the X-axis that exceed the threshold of 2 * 9.8 m/s. Also confirmed that Y and Z were below the threshold and not the cause of launch detect being triggered. After the 5 samples, verified that the state was updated to ascent.

This satisfies the condition that broke in v2.7.0 and is an effective supplement to the system tests performed for that release.

Case 2 (baro): PASS

[extracted_data.csv](https://github.com/user-attachments/files/32934029/extracted_data.csv)
[to_upload_preset.json](https://github.com/user-attachments/files/32934028/to_upload_preset.json)