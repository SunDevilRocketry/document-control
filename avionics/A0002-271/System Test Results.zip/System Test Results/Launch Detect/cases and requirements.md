## Requirements

```
Relevant requirements:
3.3: The system shall have a methods to detect if launch has occurred, including:
    3.3.1: A method based on barometric pressure.
    3.3.2: A method based on acceleration.
```

## Procedure

Case 1 (accel):

Upload attached config
Arm and shake FC
Observe state transition
Success criteria:

Observe sensor data and ensure that the threshold and counts are reached at the point where the state transitions.

Case 2 (baro):

Upload attached config
Arm and place FC in vacuum chamber and partially depressurize (use a test-only unit for safety)
Observe state transition
Success criteria:

Observe sensor data and ensure that the threshold and counts are reached at the point where the state transitions.