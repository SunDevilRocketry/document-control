Base config:
[to_upload_preset.json](https://github.com/user-attachments/files/26981101/to_upload_preset.json)

-------Test 1-------

Upload a preset
Download a preset
Run flash extract
Observe continuity between all configs, upload here

-------Test 2-------

Upload base config
Arm FC
Wait 25 seconds
Run flash extract and upload data

-------Test 3-------

Upload base config
Arm FC, shake to trigger launch detect
Wait for flash to fill (blue LED)
Run flash extract and upload data

-------Test 4-------

Upload base config with rate limit set to 100
Arm FC, shake to trigger launch detect
Run for a few seconds, then reset
Run flash extract and upload data

-------Test 5-------

Upload base config with only pre-converted data enabled
Arm FC, shake to trigger launch detect
Run for a few seconds, then reset
Run flash extract and upload data

This test verifies the following requirements:
```
3.1:	The system shall utilize the Sun Devil Rocketry “lib”, “mod”, and “driver” libraries to interface with flight computer hardware.
3.2:	The system shall have an option to log flight data.
	3.2.1:	The data that is logged shall be configurable.
3.2.2:	The data logging shall begin when launch has been detected and end when flash is full.
3.2.3:	The data logging shall have a method to reduce the sampling rate and extend the period that data is logged.
3.3:	The system shall have a methods to detect if launch has occurred, including:
	3.3.2:	A method based on acceleration.
3.4:	The system shall calibrate the IMU and barometer before launch.
3.5:	The system shall have an interface to communicate with SDEC.
3.6:	The system shall change modes from the SDEC interface to the pre-launch mode when the external switch is activated.
```