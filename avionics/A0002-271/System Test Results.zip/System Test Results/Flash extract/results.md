Test 1: PASS

[downloaded_preset.json](https://github.com/user-attachments/files/33014202/downloaded_preset.json)
[extracted_preset.json](https://github.com/user-attachments/files/33014203/extracted_preset.json)
[to_upload_preset.json](https://github.com/user-attachments/files/33014201/to_upload_preset.json)

Test 2: PASS

[extracted_data.csv](https://github.com/user-attachments/files/33014206/extracted_data.csv)
[to_upload_preset.json](https://github.com/user-attachments/files/33014205/to_upload_preset.json)

Test 3: PASS

[extracted_data.csv](https://github.com/user-attachments/files/33014208/extracted_data.csv)
[to_upload_preset.json](https://github.com/user-attachments/files/33014207/to_upload_preset.json)

Test 4: PASS
Note that the actual logging rate is closer to 90 Hz, but this is acceptable since the rate limiter sets a maximum rate.

[extracted_data.csv](https://github.com/user-attachments/files/33014263/extracted_data.csv)
[to_upload_preset.json](https://github.com/user-attachments/files/33014264/to_upload_preset.json)

Test 5: PASS 

[extracted_data.csv](https://github.com/user-attachments/files/33014268/extracted_data.csv)
[to_upload_preset.json](https://github.com/user-attachments/files/33014269/to_upload_preset.json)